#!/usr/bin/env python3
"""
Script de diagnóstico para problemas de email
Ayuda a identificar y solucionar errores de configuración
"""

import smtplib
import socket
import config
from datetime import datetime

def verificar_conectividad_internet():
    """Verifica si hay conectividad a Internet"""
    print("🌐 Verificando conectividad a Internet...")
    try:
        socket.create_connection(("8.8.8.8", 53), timeout=3)
        print("✅ Conectividad a Internet: OK")
        return True
    except OSError:
        print("❌ Conectividad a Internet: FALLO")
        print("   Verifica tu conexión a Internet")
        return False

def verificar_resolucion_dns(host):
    """Verifica si se puede resolver el nombre del servidor"""
    print(f"🔍 Verificando resolución DNS para {host}...")
    try:
        ip = socket.gethostbyname(host)
        print(f"✅ DNS resuelto: {host} -> {ip}")
        return True
    except socket.gaierror as e:
        print(f"❌ Error DNS: {e}")
        return False

def verificar_conectividad_smtp(host, port):
    """Verifica conectividad al servidor SMTP"""
    print(f"📤 Verificando conectividad SMTP a {host}:{port}...")
    try:
        with smtplib.SMTP(host, port, timeout=10) as server:
            print("✅ Conexión SMTP: OK")
            return True
    except Exception as e:
        print(f"❌ Error SMTP: {e}")
        return False

def verificar_conectividad_imap(host, port):
    """Verifica conectividad al servidor IMAP"""
    print(f"📥 Verificando conectividad IMAP a {host}:{port}...")
    try:
        import imaplib
        with imaplib.IMAP4_SSL(host, port) as server:
            print("✅ Conexión IMAP: OK")
            return True
    except Exception as e:
        print(f"❌ Error IMAP: {e}")
        return False

def verificar_credenciales_smtp(host, port, user, password):
    """Verifica las credenciales SMTP"""
    print(f"🔐 Verificando credenciales SMTP para {user}...")
    try:
        with smtplib.SMTP(host, port, timeout=10) as server:
            server.starttls()
            server.login(user, password)
            print("✅ Credenciales SMTP: OK")
            return True
    except smtplib.SMTPAuthenticationError:
        print("❌ Error de autenticación SMTP")
        print("   Verifica tu usuario y contraseña")
        return False
    except Exception as e:
        print(f"❌ Error SMTP: {e}")
        return False

def verificar_credenciales_imap(host, port, user, password):
    """Verifica las credenciales IMAP"""
    print(f"🔐 Verificando credenciales IMAP para {user}...")
    try:
        import imaplib
        with imaplib.IMAP4_SSL(host, port) as server:
            server.login(user, password)
            print("✅ Credenciales IMAP: OK")
            return True
    except imaplib.IMAP4.error:
        print("❌ Error de autenticación IMAP")
        print("   Verifica tu usuario y contraseña")
        return False
    except Exception as e:
        print(f"❌ Error IMAP: {e}")
        return False

def mostrar_configuracion_actual():
    """Muestra la configuración actual"""
    print("📋 CONFIGURACIÓN ACTUAL:")
    print("=" * 40)
    
    try:
        email_config = config.config.get_email_config()
        print(f"SMTP Host: {email_config['smtp_host']}")
        print(f"SMTP Puerto: {email_config['smtp_port']}")
        print(f"SMTP Usuario: {email_config['smtp_user']}")
        print(f"SMTP Contraseña: {'[CONFIGURADA]' if email_config['smtp_pass'] else '[NO CONFIGURADA]'}")
        print(f"IMAP Host: {email_config['imap_host']}")
        print(f"IMAP Puerto: {email_config['imap_port']}")
        print()
    except Exception as e:
        print(f"❌ Error al leer configuración: {e}")
        return False
    
    return True

def sugerir_soluciones():
    """Sugiere soluciones para problemas comunes"""
    print("💡 SOLUCIONES SUGERIDAS:")
    print("=" * 40)
    
    print("1. Para Gmail:")
    print("   - smtp_host = smtp.gmail.com")
    print("   - smtp_port = 587")
    print("   - imap_host = imap.gmail.com")
    print("   - imap_port = 993")
    print()
    
    print("2. Para Outlook/Hotmail:")
    print("   - smtp_host = smtp-mail.outlook.com")
    print("   - smtp_port = 587")
    print("   - imap_host = outlook.office365.com")
    print("   - imap_port = 993")
    print()
    
    print("3. Para Yahoo:")
    print("   - smtp_host = smtp.mail.yahoo.com")
    print("   - smtp_port = 587")
    print("   - imap_host = imap.mail.yahoo.com")
    print("   - imap_port = 993")
    print()
    
    print("4. Para Gmail, asegúrate de:")
    print("   - Habilitar autenticación de 2 factores")
    print("   - Usar una contraseña de aplicación")
    print("   - No usar tu contraseña normal")
    print()
    
    print("5. Verifica tu firewall y antivirus")
    print("   - Pueden estar bloqueando las conexiones")
    print()

def ejecutar_diagnostico_completo():
    """Ejecuta un diagnóstico completo"""
    print("🔧 DIAGNÓSTICO DE EMAIL - GESTOR DE DATOS")
    print("=" * 50)
    print(f"Fecha: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print()
    
    # Verificar configuración
    if not mostrar_configuracion_actual():
        return
    
    # Verificar conectividad básica
    if not verificar_conectividad_internet():
        return
    
    # Obtener configuración
    try:
        email_config = config.config.get_email_config()
    except Exception as e:
        print(f"❌ Error al obtener configuración: {e}")
        return
    
    # Verificar DNS
    print()
    dns_ok = verificar_resolucion_dns(email_config['smtp_host'])
    if not dns_ok:
        print("❌ No se puede resolver el servidor SMTP")
        sugerir_soluciones()
        return
    
    # Verificar conectividad SMTP
    print()
    smtp_ok = verificar_conectividad_smtp(email_config['smtp_host'], email_config['smtp_port'])
    if not smtp_ok:
        print("❌ No se puede conectar al servidor SMTP")
        sugerir_soluciones()
        return
    
    # Verificar credenciales SMTP
    print()
    if email_config['smtp_user'] and email_config['smtp_pass']:
        cred_smtp_ok = verificar_credenciales_smtp(
            email_config['smtp_host'], 
            email_config['smtp_port'],
            email_config['smtp_user'], 
            email_config['smtp_pass']
        )
        if not cred_smtp_ok:
            print("❌ Credenciales SMTP incorrectas")
            sugerir_soluciones()
            return
    else:
        print("⚠️ Credenciales SMTP no configuradas")
    
    # Verificar IMAP
    print()
    dns_imap_ok = verificar_resolucion_dns(email_config['imap_host'])
    if dns_imap_ok:
        imap_ok = verificar_conectividad_imap(email_config['imap_host'], email_config['imap_port'])
        if imap_ok and email_config['smtp_user'] and email_config['smtp_pass']:
            verificar_credenciales_imap(
                email_config['imap_host'], 
                email_config['imap_port'],
                email_config['smtp_user'], 
                email_config['smtp_pass']
            )
    
    # Resultado final
    print()
    print("🎉 DIAGNÓSTICO COMPLETADO")
    print("=" * 30)
    print("Si todos los tests pasaron, tu configuración está correcta.")
    print("Si hay errores, revisa las sugerencias arriba.")

def main():
    """Función principal"""
    try:
        ejecutar_diagnostico_completo()
    except KeyboardInterrupt:
        print("\n\n❌ Diagnóstico cancelado por el usuario")
    except Exception as e:
        print(f"\n❌ Error inesperado: {e}")

if __name__ == "__main__":
    main()
