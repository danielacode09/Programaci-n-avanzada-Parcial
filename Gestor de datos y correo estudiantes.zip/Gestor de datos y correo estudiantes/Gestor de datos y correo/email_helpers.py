import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

# 🔐 CONFIGURACIÓN DEL SERVIDOR DE CORREO
EMAIL_CONFIG = {
    "smtp_server": "smtp.gmail.com",   # Servidor SMTP de Gmail
    "smtp_port": 587,                  # Puerto
    "email_user": "tu_correo@gmail.com",   # <-- cámbialo
    "email_password": "TU_CLAVE_APP",      # <-- clave de aplicación de Gmail
    "dominios_permitidos": ["gmail.com", "outlook.com", "hotmail.com"]
}


def enviar_correos(estudiantes):
    """
    Enviar correos a estudiantes con sus promedios.
    estudiantes: lista de tuplas (Nombre, Edad, Nota1, Nota2, Nota3, Promedio, Email)
    """
    smtp_server = EMAIL_CONFIG["smtp_server"]
    smtp_port = EMAIL_CONFIG["smtp_port"]
    user = EMAIL_CONFIG["email_user"]
    password = EMAIL_CONFIG["email_password"]

    server = smtplib.SMTP(smtp_server, smtp_port)
    server.starttls()
    server.login(user, password)

    for est in estudiantes:
        nombre, edad, n1, n2, n3, promedio, correo = est

        # Validar dominio
        dominio = correo.split("@")[-1]
        if dominio not in EMAIL_CONFIG["dominios_permitidos"]:
            print(f"❌ Correo no enviado a {correo}, dominio no permitido.")
            continue

        mensaje = MIMEMultipart()
        mensaje["From"] = user
        mensaje["To"] = correo
        mensaje["Subject"] = f"Notas de {nombre}"

        cuerpo = f"""
        Hola {nombre},

        Estas son tus notas registradas:
        - Nota 1: {n1}
        - Nota 2: {n2}
        - Nota 3: {n3}

        📊 Promedio final: {promedio:.2f}

        Saludos,
        Gestor Académico
        """
        mensaje.attach(MIMEText(cuerpo, "plain"))

        try:
            server.sendmail(user, correo, mensaje.as_string())
            print(f"✅ Correo enviado a {correo}")
        except Exception as e:
            print(f"❌ Error enviando a {correo}: {e}")

    server.quit()
