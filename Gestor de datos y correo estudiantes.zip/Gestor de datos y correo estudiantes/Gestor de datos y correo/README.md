# Gestor de Datos y Correo - Versión Python

## 🎯 Descripción
Aplicación de escritorio desarrollada en Python con tkinter que demuestra el manejo de archivos CSV, operaciones con arreglos, y funcionalidades de correo electrónico.

## ✨ Características Principales

### 📊 Manejo de Archivos CSV
- ✅ Lectura y escritura de archivos CSV
- ✅ Conversión entre listas y estructuras de datos
- ✅ Búsqueda secuencial en arreglos
- ✅ Cálculo de promedios y determinación de estado académico
- ✅ Visualización en interfaz gráfica con vinculación a controles individuales

### 📧 Funcionalidades de Correo
- ✅ Envío de correos con adjuntos usando smtplib
- ✅ Validación de formato de email
- ✅ Validación por dominio (lista blanca)
- ✅ Recepción de correos usando imaplib
- ✅ Manejo seguro de credenciales

### 🖥️ Interfaz Gráfica Profesional
- ✅ Diseño moderno y profesional con paleta de colores personalizada
- ✅ Iconos intuitivos y consistentes en toda la aplicación
- ✅ Tipografías profesionales (Segoe UI)
- ✅ Treeview estilizado para mostrar datos
- ✅ Controles individuales para detalles con iconos
- ✅ Log de actividades en tiempo real con iconos de estado
- ✅ Ventana de configuración de email con diseño profesional
- ✅ Botones con estilos diferenciados (primario, éxito, peligro)
- ✅ Header con información de estado en tiempo real
- ✅ Separadores visuales y espaciado consistente

## 📁 Estructura del Proyecto

```
Gestor de datos y correo Python/
├── gestor_datos.py          # 🎯 Aplicación principal con interfaz profesional
├── csv_helpers.py           # 📊 Manejo de CSV y arreglos
├── email_helpers.py         # 📧 Funcionalidades de correo
├── config.py                # ⚙️ Manejo de configuración
├── estilos.py               # 🎨 Configuración de estilos y colores
├── config.ini               # 📝 Archivo de configuración
├── estudiantes.csv          # 📋 Datos de ejemplo
├── configurar_email.py      # 🔧 Script de configuración
├── ejecutar.py              # 🚀 Script principal
├── demo_interfaz.py         # 🎨 Demostración de interfaz profesional
├── requirements.txt         # 📦 Dependencias (vacío - solo estándar)
└── README.md                # 📚 Documentación completa
```

## 🔧 Requisitos del Sistema

### Software Necesario
- **Python 3.7 o superior**
- **tkinter** (incluido con Python)
- **Módulos estándar**: csv, smtplib, imaplib, email, re, os, datetime

### Instalación
```bash
# Clonar o descargar el proyecto
cd "Gestor de datos y correo Python"

# No se requieren dependencias adicionales
# Todos los módulos están incluidos en Python estándar
```

## ⚙️ Configuración

### 1. Configuración de Email

#### Opción A: Variables de Entorno (Recomendado)
```bash
# En Windows (CMD)
set SMTP_HOST=smtp.gmail.com
set SMTP_PORT=587
set SMTP_USER=tu-email@gmail.com
set SMTP_PASS=tu-contraseña-de-aplicacion
set IMAP_HOST=imap.gmail.com
set IMAP_PORT=993

# En Windows (PowerShell)
$env:SMTP_HOST = "smtp.gmail.com"
$env:SMTP_PORT = "587"
$env:SMTP_USER = "tu-email@gmail.com"
$env:SMTP_PASS = "tu-contraseña-de-aplicacion"
$env:IMAP_HOST = "imap.gmail.com"
$env:IMAP_PORT = "993"

# En Linux/Mac
export SMTP_HOST=smtp.gmail.com
export SMTP_PORT=587
export SMTP_USER=tu-email@gmail.com
export SMTP_PASS=tu-contraseña-de-aplicacion
export IMAP_HOST=imap.gmail.com
export IMAP_PORT=993
```

#### Opción B: Archivo config.ini
Editar el archivo `config.ini`:
```ini
[EMAIL]
smtp_host = smtp.gmail.com
smtp_port = 587
smtp_user = tu-email@gmail.com
smtp_pass = tu-contraseña-de-aplicacion
imap_host = imap.gmail.com
imap_port = 993
```

### 2. Configuración de Gmail
1. Habilitar autenticación de 2 factores
2. Generar una contraseña de aplicación
3. Usar la contraseña de aplicación en lugar de tu contraseña normal

## 🚀 Uso de la Aplicación

### Ejecutar la Aplicación

#### Opción 1: Script Principal (Recomendado)
```bash
python ejecutar.py
```
- Menú interactivo
- Verificación automática del sistema
- Configuración guiada

#### Opción 2: Ejecución Directa
```bash
python gestor_datos.py
```

#### Opción 3: Configurar Email Primero
```bash
python configurar_email.py
python gestor_datos.py
```

#### Opción 4: Ver Demostración de Interfaz
```bash
python demo_interfaz.py
```

### Funcionalidades

#### 📊 Cargar Datos CSV
1. Hacer clic en "Cargar CSV"
2. Seleccionar el archivo `estudiantes.csv` o cualquier archivo CSV válido
3. Los datos se mostrarán en la tabla

#### 🔍 Operaciones con Datos
- **Buscar**: Ingresar un nombre en el campo de búsqueda y hacer clic en "Buscar"
- **Guardar**: Hacer clic en "Guardar CSV" para exportar los datos
- **Ver Detalles**: Seleccionar una fila para ver los detalles del estudiante

#### 📧 Envío de Correos
1. Seleccionar un estudiante en la tabla
2. Configurar el email destino, asunto y cuerpo del mensaje
3. Hacer clic en "Enviar Correo"
4. El sistema creará automáticamente un archivo adjunto con la información

#### 📥 Recepción de Correos
1. Configurar las credenciales de email
2. Hacer clic en "Leer Correos" para obtener los últimos 5 correos
3. La información se mostrará en un diálogo

#### ⚙️ Configuración de Email
1. Hacer clic en "Configurar Email"
2. Ingresar los datos del servidor SMTP/IMAP
3. Hacer clic en "Guardar" y opcionalmente "Probar"

## 📋 Archivos de Ejemplo

### estudiantes.csv
```csv
Nombre,Edad,Nota1,Nota2,Nota3
Ana García,20,3.5,4.0,4.2
Luis Rodríguez,22,2.8,3.0,2.5
María López,21,4.0,4.2,3.8
Carlos Pérez,19,4.5,4.8,4.6
Sofia Martínez,23,3.2,3.5,3.0
Diego Sánchez,20,2.5,2.8,3.1
```

## 🔧 Funcionalidades Técnicas Implementadas

### 📁 Manejo de Archivos
- Lectura/escritura de archivos CSV con manejo de errores
- Operaciones con listas y estructuras de datos
- Validación de estructura de archivos

### 📧 Correo Electrónico
- Envío SMTP con SSL/TLS usando smtplib
- Validación de formato de email con expresiones regulares
- Validación por dominio (lista blanca)
- Creación automática de archivos adjuntos
- Recepción IMAP con imaplib

### 🖥️ Interfaz de Usuario
- Treeview para mostrar datos tabulares
- Controles individuales para detalles
- Log de actividades en tiempo real
- Ventana de configuración modal
- Manejo de eventos y threading

### ⚙️ Configuración
- Archivo INI para configuración persistente
- Variables de entorno como alternativa
- Validación de configuración
- Información de estado

## 🛠️ Solución de Problemas

### Error: "Las credenciales SMTP no están configuradas"
- Verificar que las variables de entorno estén configuradas
- O editar el archivo config.ini con las credenciales

### Error de autenticación con Gmail
- Verificar que se esté usando una contraseña de aplicación
- Habilitar autenticación de 2 factores en Gmail

### El archivo CSV no se carga
- Verificar que el archivo existe y tiene el formato correcto
- Asegurarse de que no hay comas dentro de los campos

### Error: "No module named 'tkinter'"
- En Linux: `sudo apt-get install python3-tk`
- En Windows/Mac: tkinter viene incluido con Python

## 📊 Comparación con la Versión C#

| Característica | C# .NET | Python |
|----------------|---------|---------|
| **Interfaz** | Windows Forms | tkinter |
| **Dependencias** | .NET Framework, MailKit | Solo Python estándar |
| **Configuración** | app.config, variables de entorno | config.ini, variables de entorno |
| **Manejo de CSV** | Librería personalizada | csv (estándar) |
| **Correo** | System.Net.Mail + MailKit | smtplib + imaplib |
| **Tamaño** | ~50MB (con dependencias) | ~5MB (solo código) |
| **Instalación** | Visual Studio, .NET Framework | Solo Python |

## 🎯 Ventajas de la Versión Python

1. **Simplicidad**: Código más conciso y legible
2. **Portabilidad**: Funciona en Windows, Linux y Mac
3. **Sin dependencias**: Solo usa módulos estándar de Python
4. **Fácil instalación**: Solo requiere Python 3.7+
5. **Mantenimiento**: Código más fácil de mantener y modificar
6. **Interfaz profesional**: Diseño moderno y atractivo
7. **Experiencia de usuario**: Iconos intuitivos y colores consistentes

## 🎨 Características de la Interfaz Profesional

### Paleta de Colores
- **Azul Principal (#2E86AB)**: Color de confianza y profesionalismo
- **Rosa/Magenta (#A23B72)**: Color creativo y moderno
- **Naranja (#F18F01)**: Color energético para acciones importantes
- **Verde (#28A745)**: Color de éxito y confirmación
- **Rojo (#DC3545)**: Color de error y advertencias

### Tipografías
- **Segoe UI**: Fuente moderna y legible de Microsoft
- **Jerarquía clara**: Títulos, subtítulos, cuerpo y texto pequeño
- **Consistencia**: Misma fuente en toda la aplicación

### Iconos
- **Más de 50 iconos**: Cubren todas las funcionalidades
- **Consistencia visual**: Mismo estilo en toda la aplicación
- **Intuitivos**: Fáciles de entender para cualquier usuario

### Componentes Estilizados
- **Botones**: Diferentes estilos según su función
- **Tablas**: Headers con colores y texto centrado
- **Campos de entrada**: Bordes sutiles y colores consistentes
- **Paneles**: Tarjetas con bordes y sombras sutiles

## ✅ Criterios de Evaluación Cumplidos

### Funcionalidad Básica (50%)
- ✅ Carga/guardado CSV
- ✅ Visualización en interfaz gráfica
- ✅ Envío de correo con adjunto
- ✅ Validación de email
- ✅ Operaciones con arreglos

### Calidad de Código (20%)
- ✅ Manejo de excepciones
- ✅ Código modular y comentado
- ✅ Separación de responsabilidades
- ✅ Uso de context managers (with)

### Interfaz y Usabilidad (10%)
- ✅ Controles bien organizados
- ✅ Mensajes claros
- ✅ Log de actividades
- ✅ Validación de entrada

### Documentación (10%)
- ✅ README completo
- ✅ Instrucciones de instalación
- ✅ Configuración de credenciales
- ✅ Solución de problemas

### Extras (10%)
- ✅ Búsqueda en arreglos
- ✅ Cálculo de promedios
- ✅ Recepción de correos
- ✅ Logs detallados
- ✅ Validación por dominio

## 📄 Licencia
Este proyecto es para fines educativos y de práctica.

## 📞 Contacto
Para preguntas o sugerencias sobre este proyecto, contactar al desarrollador.

---
**Nota**: Esta versión Python demuestra las mismas funcionalidades que la versión C#, pero con un enfoque más simple y directo, aprovechando las capacidades de Python y sus módulos estándar.
