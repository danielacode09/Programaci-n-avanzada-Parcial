#!/usr/bin/env python3
"""
Script para configurar las credenciales de email
Equivalente a los scripts configurar_email.ps1 y configurar_email.bat
"""

import os
import sys
import getpass
import configparser
from typing import Dict

def configurar_variables_entorno():
    """Configura las variables de entorno para email"""
    print("=== CONFIGURACIÓN DE EMAIL - GESTOR DE DATOS Y CORREO ===")
    print()
    
    # Configuración SMTP
    print("CONFIGURACIÓN SMTP (Envío de correos):")
    print("IMPORTANTE: Para Gmail usa 'smtp.gmail.com', NO tu dirección de email")
    smtp_host = input("Host SMTP (ej: smtp.gmail.com): ").strip() or "smtp.gmail.com"
    smtp_port = input("Puerto SMTP (ej: 587): ").strip() or "587"
    smtp_user = input("Usuario de email: ").strip()
    smtp_pass = getpass.getpass("Contraseña o contraseña de aplicación: ")
    
    # Configuración IMAP
    print()
    print("CONFIGURACIÓN IMAP (Recepción de correos):")
    print("IMPORTANTE: Para Gmail usa 'imap.gmail.com', NO tu dirección de email")
    imap_host = input("Host IMAP (ej: imap.gmail.com): ").strip() or "imap.gmail.com"
    imap_port = input("Puerto IMAP (ej: 993): ").strip() or "993"
    
    # Configurar variables de entorno
    print()
    print("Configurando variables de entorno...")
    
    os.environ["SMTP_HOST"] = smtp_host
    os.environ["SMTP_PORT"] = smtp_port
    os.environ["SMTP_USER"] = smtp_user
    os.environ["SMTP_PASS"] = smtp_pass
    os.environ["IMAP_HOST"] = imap_host
    os.environ["IMAP_PORT"] = imap_port
    
    print("Variables de entorno configuradas correctamente.")
    
    # Verificar configuración
    print()
    print("VERIFICACIÓN DE CONFIGURACIÓN:")
    print(f"SMTP_HOST: {os.environ.get('SMTP_HOST')}")
    print(f"SMTP_PORT: {os.environ.get('SMTP_PORT')}")
    print(f"SMTP_USER: {os.environ.get('SMTP_USER')}")
    print("SMTP_PASS: [OCULTO]")
    print(f"IMAP_HOST: {os.environ.get('IMAP_HOST')}")
    print(f"IMAP_PORT: {os.environ.get('IMAP_PORT')}")
    
    print()
    print("NOTAS IMPORTANTES:")
    print("- Las credenciales se han configurado en las variables de entorno de esta sesión")
    print("- Para Gmail, asegúrate de usar una contraseña de aplicación")
    print("- Las variables de entorno solo persisten durante esta sesión")
    print("- Para persistencia, edita el archivo config.ini")
    
    return {
        'smtp_host': smtp_host,
        'smtp_port': smtp_port,
        'smtp_user': smtp_user,
        'smtp_pass': smtp_pass,
        'imap_host': imap_host,
        'imap_port': imap_port
    }

def configurar_archivo_ini(configuracion: Dict[str, str]):
    """Configura el archivo config.ini"""
    print()
    respuesta = input("¿Deseas guardar la configuración en config.ini? (s/n): ").lower()
    
    if respuesta in ['s', 'si', 'sí', 'y', 'yes']:
        try:
            config = configparser.ConfigParser()
            
            # Leer configuración existente si existe
            if os.path.exists('config.ini'):
                config.read('config.ini')
            
            # Actualizar configuración de email
            if not config.has_section('EMAIL'):
                config.add_section('EMAIL')
            
            config.set('EMAIL', 'smtp_host', configuracion['smtp_host'])
            config.set('EMAIL', 'smtp_port', configuracion['smtp_port'])
            config.set('EMAIL', 'smtp_user', configuracion['smtp_user'])
            config.set('EMAIL', 'smtp_pass', configuracion['smtp_pass'])
            config.set('EMAIL', 'imap_host', configuracion['imap_host'])
            config.set('EMAIL', 'imap_port', configuracion['imap_port'])
            
            # Asegurar que existe la sección APP
            if not config.has_section('APP'):
                config.add_section('APP')
                config.set('APP', 'default_csv_file', 'estudiantes.csv')
                config.set('APP', 'max_emails_to_read', '10')
                config.set('APP', 'log_max_lines', '100')
            
            # Guardar archivo
            with open('config.ini', 'w') as f:
                config.write(f)
            
            print("Configuración guardada en config.ini exitosamente.")
            
        except Exception as e:
            print(f"Error al guardar config.ini: {e}")
    else:
        print("Configuración no guardada en archivo.")

def probar_configuracion(configuracion: Dict[str, str]):
    """Prueba la configuración de email"""
    print()
    respuesta = input("¿Deseas probar la configuración enviando un correo de prueba? (s/n): ").lower()
    
    if respuesta in ['s', 'si', 'sí', 'y', 'yes']:
        try:
            import smtplib
            from email.mime.text import MIMEText
            from email.mime.multipart import MIMEMultipart
            
            # Crear mensaje de prueba
            mensaje = MIMEMultipart()
            mensaje['From'] = configuracion['smtp_user']
            mensaje['To'] = configuracion['smtp_user']  # Enviar a sí mismo
            mensaje['Subject'] = "Correo de Prueba - Gestor de Datos"
            
            cuerpo = ("Este es un correo de prueba enviado desde el Gestor de Datos y Correo.\n\n"
                     "Si recibes este correo, la configuración SMTP está funcionando correctamente.\n\n"
                     "Saludos,\nSistema Gestor de Datos")
            
            mensaje.attach(MIMEText(cuerpo, 'plain', 'utf-8'))
            
            # Enviar correo
            with smtplib.SMTP(configuracion['smtp_host'], int(configuracion['smtp_port'])) as servidor:
                servidor.starttls()
                servidor.login(configuracion['smtp_user'], configuracion['smtp_pass'])
                servidor.send_message(mensaje)
            
            print("¡Correo de prueba enviado exitosamente!")
            print(f"Revisa tu bandeja de entrada en {configuracion['smtp_user']}")
            
        except Exception as e:
            print(f"Error al enviar correo de prueba: {e}")
            print("Verifica que las credenciales sean correctas y que tengas conexión a Internet.")

def mostrar_ayuda():
    """Muestra información de ayuda"""
    print("""
CONFIGURACIÓN DE EMAIL - GESTOR DE DATOS Y CORREO
=================================================

Este script te ayuda a configurar las credenciales de email para la aplicación.

OPCIONES:
- Variables de entorno: Se configuran para esta sesión
- Archivo config.ini: Se guarda permanentemente
- Prueba de configuración: Envía un correo de prueba

CONFIGURACIÓN DE GMAIL:
1. Habilitar autenticación de 2 factores
2. Generar una contraseña de aplicación
3. Usar la contraseña de aplicación (no tu contraseña normal)

SERVIDORES POPULARES:
- Gmail: smtp.gmail.com:587, imap.gmail.com:993
- Outlook: smtp-mail.outlook.com:587, outlook.office365.com:993
- Yahoo: smtp.mail.yahoo.com:587, imap.mail.yahoo.com:993

NOTAS IMPORTANTES:
- NUNCA compartas tus credenciales
- Usa contraseñas de aplicación cuando sea posible
- Para pruebas, considera usar servidores SMTP locales
""")

def main():
    """Función principal"""
    if len(sys.argv) > 1 and sys.argv[1] in ['-h', '--help', 'help']:
        mostrar_ayuda()
        return
    
    try:
        configuracion = configurar_variables_entorno()
        configurar_archivo_ini(configuracion)
        probar_configuracion(configuracion)
        
        print()
        print("Configuración completada. Puedes ejecutar la aplicación ahora.")
        print("Ejecuta: python gestor_datos.py")
        
    except KeyboardInterrupt:
        print("\n\nConfiguración cancelada por el usuario.")
    except Exception as e:
        print(f"\nError inesperado: {e}")

if __name__ == "__main__":
    main()
