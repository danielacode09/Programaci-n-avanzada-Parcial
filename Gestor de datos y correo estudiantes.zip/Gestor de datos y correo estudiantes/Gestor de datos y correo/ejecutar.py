#!/usr/bin/env python3
"""
Script principal para ejecutar el Gestor de Datos y Correo
Incluye verificación de dependencias y configuración inicial
"""

import sys
import os

def verificar_python():
    """Verifica que la versión de Python sea compatible"""
    version = sys.version_info
    if version.major < 3 or (version.major == 3 and version.minor < 7):
        print("❌ Error: Se requiere Python 3.7 o superior")
        print(f"   Versión actual: {version.major}.{version.minor}.{version.micro}")
        return False
    
    print(f"✅ Python {version.major}.{version.minor}.{version.micro} - Compatible")
    return True

def verificar_modulos():
    """Verifica que los módulos necesarios estén disponibles"""
    modulos_requeridos = [
        'tkinter',
        'csv',
        'smtplib',
        'imaplib',
        'email',
        're',
        'os',
        'datetime',
        'configparser',
        'threading',
            ]
    
    modulos_faltantes = []
    
    for modulo in modulos_requeridos:
        try:
            __import__(modulo)
            print(f"✅ {modulo} - Disponible")
        except ImportError:
            print(f"❌ {modulo} - No disponible")
            modulos_faltantes.append(modulo)
    
    if modulos_faltantes:
        print(f"\n❌ Módulos faltantes: {', '.join(modulos_faltantes)}")
        return False
    
    return True

def verificar_archivos():
    """Verifica que los archivos necesarios estén presentes"""
    archivos_requeridos = [
        'gestor_datos.py',
        'csv_helpers.py',
        'email_helpers.py',
        'config.py',
        'estudiantes.csv'
    ]
    
    archivos_faltantes = []
    
    for archivo in archivos_requeridos:
        if os.path.exists(archivo):
            print(f"✅ {archivo} - Presente")
        else:
            print(f"❌ {archivo} - Faltante")
            archivos_faltantes.append(archivo)
    
    if archivos_faltantes:
        print(f"\n❌ Archivos faltantes: {', '.join(archivos_faltantes)}")
        return False
    
    return True

def crear_config_ini_si_no_existe():
    """Crea config.ini si no existe"""
    if not os.path.exists('config.ini'):
        print("📝 Creando archivo config.ini...")
        try:
            import config
            # El archivo se creará automáticamente al importar config
            print("✅ config.ini creado exitosamente")
        except Exception as e:
            print(f"❌ Error al crear config.ini: {e}")
            return False
    else:
        print("✅ config.ini - Presente")
    
    return True

def verificar_configuracion_email():
    """Verifica si la configuración de email está completa"""
    try:
        import config
        if config.config.is_email_configured():
            print("✅ Configuración de email - Completa")
            return True
        else:
            print("⚠️  Configuración de email - Incompleta")
            print("   Ejecuta: python configurar_email.py")
            return False
    except Exception as e:
        print(f"❌ Error al verificar configuración: {e}")
        return False

def mostrar_menu():
    """Muestra el menú de opciones"""
    print("\n" + "="*50)
    print("GESTOR DE DATOS Y CORREO - PYTHON")
    print("="*50)
    print("1. Ejecutar aplicación")
    print("2. Configurar email")
    print("3. Verificar sistema")
    print("4. Diagnóstico de email")
    print("5. Mostrar ayuda")
    print("6. Salir")
    print("="*50)

def mostrar_ayuda():
    """Muestra información de ayuda"""
    print("""
AYUDA - GESTOR DE DATOS Y CORREO
================================

DESCRIPCIÓN:
Aplicación de escritorio para gestión de datos CSV y envío de correos.

FUNCIONALIDADES:
- Cargar y guardar archivos CSV
- Visualizar datos en tabla
- Buscar estudiantes por nombre
- Calcular promedios y estados
- Enviar correos con adjuntos
- Leer correos desde servidor
- Validación de emails y dominios

REQUISITOS:
- Python 3.7 o superior
- Módulos estándar de Python (tkinter, csv, smtplib, etc.)

CONFIGURACIÓN:
1. Ejecutar: python configurar_email.py
2. Ingresar credenciales de email
3. Probar configuración

ARCHIVOS IMPORTANTES:
- gestor_datos.py: Aplicación principal
- estudiantes.csv: Datos de ejemplo
- config.ini: Configuración de email
- README.md: Documentación completa

SOLUCIÓN DE PROBLEMAS:
- Si tkinter no funciona: sudo apt-get install python3-tk (Linux)
- Si hay errores de email: Verificar credenciales y conexión
- Si no carga CSV: Verificar formato del archivo

CONTACTO:
Para soporte técnico, consultar la documentación.
""")

def ejecutar_aplicacion():
    """Ejecuta la aplicación principal"""
    try:
        print("🚀 Iniciando aplicación...")
        import gestor_datos
        gestor_datos.main()
    except Exception as e:
        print(f"❌ Error al ejecutar la aplicación: {e}")
        print("   Verifica que todos los archivos estén presentes")

def configurar_email():
    """Ejecuta el script de configuración de email"""
    try:
        print("📧 Iniciando configuración de email...")
        import configurar_email
        configurar_email.main()
    except Exception as e:
        print(f"❌ Error al configurar email: {e}")

def diagnostico_email():
    """Ejecuta el diagnóstico de email"""
    try:
        print("🔧 Iniciando diagnóstico de email...")
        import diagnostico_email
        diagnostico_email.main()
    except Exception as e:
        print(f"❌ Error al ejecutar diagnóstico: {e}")

def verificar_sistema():
    """Verifica el sistema completo"""
    print("\n🔍 VERIFICACIÓN DEL SISTEMA")
    print("="*30)
    
    # Verificar Python
    if not verificar_python():
        return False
    
    print()
    
    # Verificar módulos
    if not verificar_modulos():
        return False
    
    print()
    
    # Verificar archivos
    if not verificar_archivos():
        return False
    
    print()
    
    # Crear config.ini si no existe
    if not crear_config_ini_si_no_existe():
        return False
    
    print()
    
    # Verificar configuración de email
    verificar_configuracion_email()
    
    print("\n✅ Verificación del sistema completada")
    return True

def main():
    """Función principal"""
    while True:
        mostrar_menu()
        
        try:
            opcion = input("\nSelecciona una opción (1-6): ").strip()
            
            if opcion == '1':
                if verificar_sistema():
                    ejecutar_aplicacion()
                else:
                    print("\n❌ El sistema no está listo. Corrige los errores antes de continuar.")
            
            elif opcion == '2':
                configurar_email()
            
            elif opcion == '3':
                verificar_sistema()
            
            elif opcion == '4':
                diagnostico_email()
            
            elif opcion == '5':
                mostrar_ayuda()
            
            elif opcion == '6':
                print("\n👋 ¡Hasta luego!")
                break
            
            else:
                print("\n❌ Opción inválida. Selecciona 1-6.")
            
            input("\nPresiona Enter para continuar...")
            
        except KeyboardInterrupt:
            print("\n\n👋 ¡Hasta luego!")
            break
        except Exception as e:
            print(f"\n❌ Error inesperado: {e}")
            input("Presiona Enter para continuar...")

if __name__ == "__main__":
    main()
