"""
Módulo para manejo de archivos CSV y operaciones con arreglos
Equivalente a FileHelpers.cs en la versión C#
"""

import csv
import os
from typing import List
from datetime import datetime

class CSVHelpers:
    """Clase estática para manejo de archivos CSV y operaciones con arreglos"""
    
    @staticmethod
    def leer_csv(ruta: str) -> List[List[str]]:
        """
        Lee un archivo CSV y devuelve una lista de listas (cada fila -> columnas)
        
        Args:
            ruta: Ruta del archivo CSV a leer
            
        Returns:
            Lista de listas de strings, donde cada lista representa una fila
            
        Raises:
            FileNotFoundError: Cuando el archivo no existe
            Exception: Cuando ocurre un error durante la lectura
        """
        try:
            if not os.path.exists(ruta):
                raise FileNotFoundError(f"El archivo {ruta} no existe.")
            
            filas = []
            with open(ruta, 'r', encoding='utf-8', newline='') as archivo:
                lector = csv.reader(archivo)
                for fila in lector:
                    if fila:  # Ignorar filas vacías
                        filas.append(fila)
            
            return filas
            
        except Exception as e:
            raise Exception(f"Error al leer el archivo CSV: {str(e)}")
    
    @staticmethod
    def guardar_csv(ruta: str, filas: List[List[str]]) -> None:
        """
        Guarda una lista de listas en formato CSV
        
        Args:
            ruta: Ruta donde guardar el archivo
            filas: Lista de listas de strings a guardar
            
        Raises:
            Exception: Cuando ocurre un error durante la escritura
        """
        try:
            if filas is None:
                raise ValueError("La lista de filas no puede ser None")
            
            with open(ruta, 'w', encoding='utf-8', newline='') as archivo:
                escritor = csv.writer(archivo)
                for fila in filas:
                    if fila is not None:
                        escritor.writerow(fila)
                        
        except Exception as e:
            raise Exception(f"Error al guardar el archivo CSV: {str(e)}")
    
    @staticmethod
    def leer_csv_datos(ruta: str, tiene_cabecera: bool = True) -> List[List[str]]:
        """
        Lee un archivo CSV y devuelve solo las filas de datos (sin cabecera)
        
        Args:
            ruta: Ruta del archivo CSV
            tiene_cabecera: Indica si la primera fila es una cabecera
            
        Returns:
            Lista de listas de strings con los datos
        """
        todas_las_filas = CSVHelpers.leer_csv(ruta)
        
        if tiene_cabecera and todas_las_filas:
            # Remover la primera fila (cabecera)
            todas_las_filas.pop(0)
        
        return todas_las_filas
    
    @staticmethod
    def obtener_cabeceras(ruta: str) -> List[str]:
        """
        Obtiene las cabeceras de un archivo CSV
        
        Args:
            ruta: Ruta del archivo CSV
            
        Returns:
            Lista de strings con las cabeceras
        """
        todas_las_filas = CSVHelpers.leer_csv(ruta)
        
        if todas_las_filas:
            return todas_las_filas[0]
        
        return []
    
    @staticmethod
    def validar_estructura(filas: List[List[str]]) -> bool:
        """
        Valida que todas las filas tengan el mismo número de columnas
        
        Args:
            filas: Lista de listas de strings
            
        Returns:
            True si todas las filas tienen el mismo número de columnas
        """
        if not filas:
            return True
        
        numero_columnas = len(filas[0])
        
        for fila in filas:
            if len(fila) != numero_columnas:
                return False
        
        return True
    
    @staticmethod
    def obtener_info_archivo(ruta: str) -> str:
        """
        Obtiene información sobre el archivo CSV
        
        Args:
            ruta: Ruta del archivo CSV
            
        Returns:
            String con información del archivo
        """
        try:
            if not os.path.exists(ruta):
                return "El archivo no existe."
            
            filas = CSVHelpers.leer_csv(ruta)
            info = []
            
            info.append(f"Archivo: {os.path.basename(ruta)}")
            info.append(f"Ruta completa: {ruta}")
            info.append(f"Número de filas: {len(filas)}")
            
            if filas:
                info.append(f"Número de columnas: {len(filas[0])}")
                info.append(f"Estructura válida: {CSVHelpers.validar_estructura(filas)}")
            
            file_info = os.stat(ruta)
            info.append(f"Tamaño: {file_info.st_size} bytes")
            info.append(f"Última modificación: {datetime.fromtimestamp(file_info.st_mtime)}")
            
            return "\n".join(info)
            
        except Exception as e:
            return f"Error al obtener información: {str(e)}"
    
    @staticmethod
    def crear_archivo_ejemplo(ruta: str) -> None:
        """
        Crea un archivo CSV de ejemplo con datos de estudiantes
        
        Args:
            ruta: Ruta donde crear el archivo
        """
        datos_ejemplo = [
            ["Nombre", "Edad", "Nota1", "Nota2", "Nota3"],
            ["Ana García", "20", "3.5", "4.0", "4.2"],
            ["Luis Rodríguez", "22", "2.8", "3.0", "2.5"],
            ["María López", "21", "4.0", "4.2", "3.8"],
            ["Carlos Pérez", "19", "4.5", "4.8", "4.6"],
            ["Sofia Martínez", "23", "3.2", "3.5", "3.0"],
            ["Diego Sánchez", "20", "2.5", "2.8", "3.1"]
        ]
        
        CSVHelpers.guardar_csv(ruta, datos_ejemplo)

class ArrayHelpers:
    """Clase para operaciones con arreglos (equivalente a las funciones de FileHelpers.cs)"""
    
    @staticmethod
    def busqueda_secuencial(vector: List[str], valor: str) -> int:
        """
        Búsqueda secuencial en un vector (arreglo unidimensional)
        
        Args:
            vector: Lista donde buscar
            valor: Valor a buscar
            
        Returns:
            Índice del elemento encontrado, -1 si no se encuentra
        """
        for i, elemento in enumerate(vector):
            if elemento.lower() == valor.lower():
                return i
        return -1
    
    @staticmethod
    def calcular_promedio(notas: List[str]) -> float:
        """
        Calcula el promedio de las notas de un estudiante
        
        Args:
            notas: Lista con las notas (strings que representan números)
            
        Returns:
            Promedio calculado
        """
        suma = 0
        contador = 0
        
        for nota in notas:
            try:
                valor_nota = float(nota)
                suma += valor_nota
                contador += 1
            except ValueError:
                continue  # Ignorar valores que no se pueden convertir a float
        
        return suma / contador if contador > 0 else 0
    
    @staticmethod
    def esta_aprobado(promedio: float, nota_minima: float = 3.0) -> bool:
        """
        Determina si un estudiante está aprobado basado en su promedio
        
        Args:
            promedio: Promedio del estudiante
            nota_minima: Nota mínima para aprobar (por defecto 3.0)
            
        Returns:
            True si está aprobado, False si está reprobado
        """
        return promedio >= nota_minima
    
    @staticmethod
    def buscar_estudiante_por_nombre(datos: List[List[str]], nombre: str) -> int:
        """
        Busca un estudiante por nombre en la lista de datos
        
        Args:
            datos: Lista de datos de estudiantes
            nombre: Nombre a buscar
            
        Returns:
            Índice del estudiante encontrado, -1 si no se encuentra
        """
        if not datos:
            return -1
        
        # Asumimos que la primera columna es el nombre
        for i, fila in enumerate(datos):
            if fila and len(fila) > 0:
                if fila[0].lower() == nombre.lower():
                    return i
        
        return -1
    import csv

def leer_csv(ruta):
    """Lee un archivo CSV y retorna la lista de filas"""
    with open(ruta, newline='', encoding="utf-8") as f:
        reader = csv.reader(f)
        return list(reader)

def guardar_csv(ruta, filas):
    """Guarda los datos en un archivo CSV"""
    with open(ruta, mode="w", newline='', encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerows(filas)

