# 🔧 Solución del Error de Email

##  Error Identificado
```
[Errno 11003] getaddrinfo failed
```

##  Causa del Problema
El error indica que no se puede resolver el nombre del servidor SMTP. En tu configuración tenías:
- `smtp_host = daniela.ayerbec@cun.edu.co` ❌ (INCORRECTO)
- `imap_host = daniela.ayerbec@cun.edu.co` ❌ (INCORRECTO)

##  Solución Aplicada
He corregido tu archivo `config.ini` con la configuración correcta:
- `smtp_host = smtp.gmail.com` ✅ (CORRECTO)
- `imap_host = imap.gmail.com` ✅ (CORRECTO)

##  Pasos para Verificar la Solución

### 1. Ejecutar Diagnóstico
```bash
python diagnostico_email.py
```

### 2. Usar el Script Principal
```bash
python ejecutar.py
# Seleccionar opción 4: Diagnóstico de email
```

### 3. Probar Envío de Correo
```bash
python gestor_datos.py
# Intentar enviar un correo de prueba
```

## 📧 Configuración Correcta para Gmail

### Archivo config.ini
```ini
[EMAIL]
smtp_host = smtp.gmail.com
smtp_port = 587
smtp_user = daniela.ayerbec@cun.edu.co
smtp_pass = tu_contraseña_de_aplicacion
imap_host = imap.gmail.com
imap_port = 993
```

### Variables de Entorno (Alternativa)
```bash
# Windows
set SMTP_HOST=smtp.gmail.com
set SMTP_PORT=587
set SMTP_USER=daniela.ayerbec@cun.edu.co
set SMTP_PASS=tu_contraseña_de_aplicacion
set IMAP_HOST=imap.gmail.com
set IMAP_PORT=993

# Linux/Mac
export SMTP_HOST=smtp.gmail.com
export SMTP_PORT=587
export SMTP_USER=daniela.ayerbec@cun.edu.co
export SMTP_PASS=tu_contraseña_de_aplicacion
export IMAP_HOST=imap.gmail.com
export IMAP_PORT=993
```

## Importante para Gmail

### 1. Contraseña de Aplicación
- **NO uses tu contraseña normal de Gmail**
- Debes usar una **contraseña de aplicación**
- Para crear una:
  1. Ve a tu cuenta de Google
  2. Seguridad → Verificación en 2 pasos
  3. Contraseñas de aplicaciones
  4. Genera una nueva contraseña

### 2. Autenticación de 2 Factores
- Debe estar habilitada en tu cuenta de Gmail
- Es obligatoria para usar contraseñas de aplicación

## 🔍 Otros Servidores de Email

### Outlook/Hotmail
```ini
smtp_host = smtp-mail.outlook.com
smtp_port = 587
imap_host = outlook.office365.com
imap_port = 993
```

### Yahoo
```ini
smtp_host = smtp.mail.yahoo.com
smtp_port = 587
imap_host = imap.mail.yahoo.com
imap_port = 993
```

## 🛠️ Solución de Problemas Adicionales

### Si el error persiste:

1. **Verificar Conectividad**
   ```bash
   python diagnostico_email.py
   ```

2. **Verificar Firewall/Antivirus**
   - Pueden estar bloqueando las conexiones
   - Agregar excepción para Python

3. **Verificar DNS**
   - Probar con otro DNS (8.8.8.8, 1.1.1.1)

4. **Verificar Proxy**
   - Si usas proxy corporativo, configurarlo

##  Soporte

Si el problema persiste después de seguir estos pasos:
1. Ejecuta el diagnóstico completo
2. Copia el resultado completo
3. Verifica que tengas conectividad a Internet
4. Confirma que tu cuenta de Gmail tenga 2FA habilitado

## Verificación Final

Para confirmar que todo funciona:
1. Ejecuta `python diagnostico_email.py`
2. Todos los tests deben mostrar ✅
3. Intenta enviar un correo desde la aplicación
4. Debería funcionar sin errores

