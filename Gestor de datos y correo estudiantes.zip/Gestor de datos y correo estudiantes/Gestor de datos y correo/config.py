"""
Configuración para el Gestor de Datos y Correo
Maneja la configuración de email y otros parámetros
"""

import os
import configparser
from typing import Dict, Any

class Config:
    """Clase para manejar la configuración de la aplicación"""
    
    def __init__(self, config_file: str = "config.ini"):
        self.config_file = config_file
        self.config = configparser.ConfigParser()
        self.load_config()
    
    def load_config(self):
        """Carga la configuración desde archivo o variables de entorno"""
        # Configuración por defecto
        default_config = {
            'EMAIL': {
                'smtp_host': 'smtp.gmail.com',
                'smtp_port': '587',
                'smtp_user': '',
                'smtp_pass': '',
                'imap_host': 'imap.gmail.com',
                'imap_port': '993'
            },
            'APP': {
                'default_csv_file': 'estudiantes.csv',
                'max_emails_to_read': '10',
                'log_max_lines': '100'
            }
        }
        
        # Crear archivo de configuración si no existe
        if not os.path.exists(self.config_file):
            self.config.read_dict(default_config)
            self.save_config()
        else:
            self.config.read(self.config_file)
    
    def save_config(self):
        """Guarda la configuración en el archivo"""
        with open(self.config_file, 'w') as f:
            self.config.write(f)
    
    def get_email_config(self) -> Dict[str, str]:
        """Obtiene la configuración de email desde archivo o variables de entorno"""
        # Prioridad: Variables de entorno > archivo de configuración > valores por defecto
        
        smtp_host = (os.getenv('SMTP_HOST') or 
                    self.config.get('EMAIL', 'smtp_host', fallback='smtp.gmail.com'))
        
        smtp_port = (os.getenv('SMTP_PORT') or 
                    self.config.get('EMAIL', 'smtp_port', fallback='587'))
        
        smtp_user = (os.getenv('SMTP_USER') or 
                    self.config.get('EMAIL', 'smtp_user', fallback=''))
        
        smtp_pass = (os.getenv('SMTP_PASS') or 
                    self.config.get('EMAIL', 'smtp_pass', fallback=''))
        
        imap_host = (os.getenv('IMAP_HOST') or 
                    self.config.get('EMAIL', 'imap_host', fallback='imap.gmail.com'))
        
        imap_port = (os.getenv('IMAP_PORT') or 
                    self.config.get('EMAIL', 'imap_port', fallback='993'))
        
        return {
            'smtp_host': smtp_host,
            'smtp_port': int(smtp_port),
            'smtp_user': smtp_user,
            'smtp_pass': smtp_pass,
            'imap_host': imap_host,
            'imap_port': int(imap_port)
        }
    
    def get_app_config(self) -> Dict[str, Any]:
        """Obtiene la configuración de la aplicación"""
        return {
            'default_csv_file': self.config.get('APP', 'default_csv_file', fallback='estudiantes.csv'),
            'max_emails_to_read': int(self.config.get('APP', 'max_emails_to_read', fallback='10')),
            'log_max_lines': int(self.config.get('APP', 'log_max_lines', fallback='100'))
        }
    
    def update_email_config(self, **kwargs):
        """Actualiza la configuración de email"""
        for key, value in kwargs.items():
            if key in ['smtp_host', 'smtp_port', 'smtp_user', 'smtp_pass', 'imap_host', 'imap_port']:
                self.config.set('EMAIL', key, str(value))
        self.save_config()
    
    def is_email_configured(self) -> bool:
        """Verifica si la configuración de email está completa"""
        config = self.get_email_config()
        return bool(config['smtp_user'] and config['smtp_pass'])
    
    def get_config_info(self) -> str:
        """Obtiene información sobre la configuración actual"""
        config = self.get_email_config()
        configured = self.is_email_configured()
        
        info = f"""Configuración de Email:
Host SMTP: {config['smtp_host']}
Puerto SMTP: {config['smtp_port']}
Usuario: {config['smtp_user'] if configured else 'No configurado'}
Contraseña: {'[CONFIGURADA]' if configured else '[NO CONFIGURADA]'}
Host IMAP: {config['imap_host']}
Puerto IMAP: {config['imap_port']}
Estado: {'Configurado' if configured else 'No configurado'}"""
        
        return info

# Instancia global de configuración
config = Config()
