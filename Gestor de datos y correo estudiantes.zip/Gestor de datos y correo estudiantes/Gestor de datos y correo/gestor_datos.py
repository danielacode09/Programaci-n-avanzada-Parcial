import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import pandas as pd
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
import estilos
import os

# -------------------------------
# 📌 Variables globales
# -------------------------------
df = pd.DataFrame(columns=["Nombre", "Edad", "Nota1", "Nota2", "Nota3", "Promedio", "Estado"])

# -------------------------------
# 📌 Funciones principales
# -------------------------------
def calcular_promedio(n1, n2, n3):
    return round((n1 + n2 + n3) / 3, 2)

def agregar_estudiante():
    nombre = entry_nombre.get()
    edad = entry_edad.get()
    try:
        n1 = float(entry_n1.get())
        n2 = float(entry_n2.get())
        n3 = float(entry_n3.get())
    except ValueError:
        messagebox.showerror("Error", "Notas inválidas")
        return

    promedio = calcular_promedio(n1, n2, n3)
    estado = "Aprobado ✅" if promedio >= 3.0 else "Reprobado ❌"

    global df
    df.loc[len(df)] = [nombre, edad, n1, n2, n3, promedio, estado]
    actualizar_tabla()
    limpiar_campos()

def actualizar_tabla():
    for row in tree.get_children():
        tree.delete(row)
    for _, fila in df.iterrows():
        tree.insert("", "end", values=list(fila))

def limpiar_campos():
    entry_nombre.delete(0, tk.END)
    entry_edad.delete(0, tk.END)
    entry_n1.delete(0, tk.END)
    entry_n2.delete(0, tk.END)
    entry_n3.delete(0, tk.END)

def guardar_csv():
    file = filedialog.asksaveasfilename(defaultextension=".csv")
    if file:
        df.to_csv(file, index=False)
        messagebox.showinfo("Éxito", "Archivo guardado correctamente")

def cargar_csv():
    global df
    file = filedialog.askopenfilename(filetypes=[("CSV files", "*.csv")])
    if file:
        df = pd.read_csv(file)

        # Recalcular promedio y estado
        df["Promedio"] = df[["Nota1", "Nota2", "Nota3"]].mean(axis=1).round(2)
        df["Estado"] = df["Promedio"].apply(lambda x: "Aprobado ✅" if x >= 3.0 else "Reprobado ❌")

        actualizar_tabla()

def buscar_estudiantes():
    filtro = entry_buscar.get().lower()
    for row in tree.get_children():
        tree.delete(row)
    for _, fila in df.iterrows():
        if filtro in str(fila['Nombre']).lower():
            tree.insert("", "end", values=list(fila))

def enviar_correo():
    destinatario = entry_email.get()
    if not estilos.validate_email(destinatario):
        messagebox.showerror("Error", "Correo no válido o dominio no permitido")
        return

    seleccion = tree.selection()
    if not seleccion:
        messagebox.showerror("Error", "Selecciona un estudiante en la tabla")
        return

    datos = tree.item(seleccion[0], "values")
    if not datos:
        messagebox.showerror("Error", "No se encontraron datos del estudiante")
        return

    nombre, edad, n1, n2, n3, promedio, estado = datos

    try:
        # Crear mensaje con datos del estudiante
        msg = MIMEMultipart()
        msg["From"] = "daniela.ayerbec@cun.edu.co"
        msg["To"] = destinatario
        msg["Subject"] = f"Informe Académico de {nombre}"

        cuerpo = f"""
        Informe Académico
        -------------------------
        Nombre: {nombre}
        Edad: {edad}
        Nota1: {n1}
        Nota2: {n2}
        Nota3: {n3}
        Promedio: {promedio}
        Estado: {estado}
    
        -------------------------
        """

        msg.attach(MIMEText(cuerpo, "plain"))

        # Enviar correo
        server = smtplib.SMTP("smtp.gmail.com", 587)
        server.starttls()
        server.login("daniela.ayerbec@cun.edu.co", "iayg htkp sysd ascc")  # ⚠️ contraseña de aplicación
        server.send_message(msg)
        server.quit()

        messagebox.showinfo("Éxito", f"Correo enviado a {destinatario}")
    except Exception as e:
        messagebox.showerror("Error", f"No se pudo enviar el correo: {e}")

# -------------------------------
# 📌 Interfaz gráfica
# -------------------------------
root = tk.Tk()
root.title(estilos.APP_CONFIG["name"])
root.geometry(f"{estilos.APP_CONFIG['default_width']}x{estilos.APP_CONFIG['default_height']}")
root.configure(bg=estilos.COLORS['light'])

# 🖼️ Título principal
titulo = tk.Label(root, text="📘 Gestor de Notas y Correos",
                font=("Arial", 20, "bold"),
                bg=estilos.COLORS['light'],
                fg=estilos.COLORS['primary'])
titulo.pack(pady=10)

root.title("gestor académico de estudiantes")



# 🔍 Barra de búsqueda
frame_buscar = tk.Frame(root, bg=estilos.COLORS['light'])
frame_buscar.pack(fill="x", pady=10, padx=10)

tk.Label(frame_buscar, text="Buscar estudiante:",
        font=estilos.FONTS['subtitle'], bg=estilos.COLORS['light']).pack(side="left", padx=5)

entry_buscar = tk.Entry(frame_buscar, width=30, font=estilos.FONTS['body'])
entry_buscar.pack(side="left", padx=5)

btn_buscar = tk.Button(frame_buscar, text="Buscar", bg=estilos.COLORS['primary'], fg="white",
                    font=estilos.FONTS['button'], command=buscar_estudiantes)
btn_buscar.pack(side="left", padx=5)

# 📋 Formulario
frame_form = tk.Frame(root, bg=estilos.COLORS['light'])
frame_form.pack(fill="x", padx=10, pady=10)

labels = ["Nombre", "Edad", "Nota1", "Nota2", "Nota3"]
entries = []
for i, label in enumerate(labels):
    tk.Label(frame_form, text=label, font=estilos.FONTS['body'], bg=estilos.COLORS['light']).grid(row=0, column=i, padx=5)
    entry = tk.Entry(frame_form, width=12)
    entry.grid(row=1, column=i, padx=5)
    entries.append(entry)

entry_nombre, entry_edad, entry_n1, entry_n2, entry_n3 = entries

btn_agregar = tk.Button(frame_form, text="Agregar estudiante", bg=estilos.COLORS['secondary'], fg="white",
                        font=estilos.FONTS['button'], command=agregar_estudiante)
btn_agregar.grid(row=1, column=len(labels), padx=10)

# 📊 Tabla
frame_tabla = tk.Frame(root)
frame_tabla.pack(fill="both", expand=True, padx=10, pady=10)

cols = ["Nombre", "Edad", "Nota1", "Nota2", "Nota3", "Promedio", "Estado"]
tree = ttk.Treeview(frame_tabla, columns=cols, show="headings")

for col in cols:
    tree.heading(col, text=col)
    tree.column(col, anchor="center", width=120)

tree.pack(fill="both", expand=True)

# 📂 Botones archivo
frame_botones = tk.Frame(root, bg=estilos.COLORS['light'])
frame_botones.pack(fill="x", pady=10)

tk.Button(frame_botones, text="Guardar CSV", bg=estilos.COLORS['primary'], fg="white",
        font=estilos.FONTS['button'], command=guardar_csv).pack(side="left", padx=5)

tk.Button(frame_botones, text="Cargar CSV", bg=estilos.COLORS['accent'], fg="white",
        font=estilos.FONTS['button'], command=cargar_csv).pack(side="left", padx=5)

# 📧 Envío de correos
frame_email = tk.Frame(root, bg=estilos.COLORS['light'])
frame_email.pack(fill="x", pady=10, padx=10)

tk.Label(frame_email, text="Correo destinatario:", font=estilos.FONTS['body'], bg=estilos.COLORS['light']).pack(side="left", padx=5)
entry_email = tk.Entry(frame_email, width=30, font=estilos.FONTS['body'])
entry_email.pack(side="left", padx=5)
btn_enviar = tk.Button(frame_email, text="Enviar correo", bg=estilos.COLORS['danger'], fg="white",
                    font=estilos.FONTS['button'], command=enviar_correo)
btn_enviar.pack(side="left", padx=5)

# 🏁 Loop principal
root.mainloop()
