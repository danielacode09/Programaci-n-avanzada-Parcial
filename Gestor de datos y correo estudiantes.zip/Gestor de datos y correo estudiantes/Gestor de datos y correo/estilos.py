"""
Módulo de estilos personalizados para la aplicación
Contiene configuraciones de colores, fuentes, validaciones y temas
"""

# 🎨 Paleta de colores
COLORS = {
    'primary': '#4A90E2',      # Azul moderno
    'secondary': '#D64550',    # Rojo coral
    'accent': '#F5A623',       # Amarillo cálido

    # Estados
    'success': '#2ECC71',
    'warning': '#F1C40F',
    'danger': '#E74C3C',
    'info': '#3498DB',

    # Neutros
    'light': '#F9F9F9',
    'dark': '#2C3E50',
    'white': '#FFFFFF',
    'gray': '#7F8C8D',
    'border': '#BDC3C7'
}

# 📝 Fuentes
FONTS = {
    'title': ('Segoe UI', 18, 'bold'),
    'subtitle': ('Segoe UI', 12, 'bold'),
    'body': ('Segoe UI', 10),
    'button': ('Segoe UI', 10, 'bold')
}

# 🔲 Bordes y sombras
RADIUS = {
    'small': 4,
    'medium': 8,
    'large': 12
}

SHADOWS = {
    'small': '0 1px 3px rgba(0,0,0,0.12)',
    'medium': '0 3px 6px rgba(0,0,0,0.16)',
    'large': '0 10px 20px rgba(0,0,0,0.19)'
}

# ✅ Validaciones
VALIDATION = {
    'email_pattern': r'^[^@\s]+@[^@\s]+\.[^@\s]+$',
    'number_pattern': r'^\d+(\.\d+)?$'
}

# 📧 Configuración de email
EMAIL_CONFIG = {
    'default_smtp_ports': [25, 587, 465],
    'allowed_domains': ['gmail.com', 'outlook.com', 'hotmail.com', 'yahoo.com'],
    'timeout': 30,
    'max_retries': 3
}

# 📦 Configuración de la app
APP_CONFIG = {
    'name': 'Gestor Académico',
    'version': '3.0',
    'author': 'Sistema Escolar',
    'description': 'Gestión de estudiantes con búsqueda y envío de correos',
    'default_width': 1200,
    'default_height': 700
}

# -------------------------------
# 🔧 Funciones de ayuda
# -------------------------------
def validate_email(email):
    """Valida formato y dominio del correo"""
    import re
    if not re.match(VALIDATION['email_pattern'], email):
        return False
    dominio = email.split('@')[-1]
    return dominio in EMAIL_CONFIG['allowed_domains']

def validate_number(number):
    """Valida que sea un número"""
    import re
    return bool(re.match(VALIDATION['number_pattern'], str(number)))
BG_COLOR = "#F4F4F4"
FG_COLOR = "#333333"
BUTTON_COLOR = "#4A90E2"
HIGHLIGHT_COLOR = "#D64550"
FONT_FAMILY = "Segoe UI"    
FONT_SIZE = 10
FONT_BOLD = "bold"
FONT_ITALIC = "italic"
FONT_UNDERLINE = "underline"

